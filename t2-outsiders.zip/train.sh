export PATH=/usr/conda/bin:$PATH
python IDAO2022-outsiders-final.py